'use client'

import { useEffect, useState } from 'react'
import { DoorClosed, Eye } from 'lucide-react'
import { recordVisit } from '@/app/actions/stats'
import type { SiteStats } from '@/lib/stats'

const VISIT_FLAG = 'andranto-visit-recorded'
const numberFormat = new Intl.NumberFormat('fr-FR')

export function VisitCount({ initial }: { initial: SiteStats }) {
  const [stats, setStats] = useState(initial)

  useEffect(() => {
    if (sessionStorage.getItem(VISIT_FLAG)) return
    sessionStorage.setItem(VISIT_FLAG, '1')
    recordVisit()
      .then(setStats)
      .catch(() => sessionStorage.removeItem(VISIT_FLAG))
  }, [])

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 text-xs font-medium">
      <span
        className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/80 px-3 py-1 text-foreground shadow-sm backdrop-blur"
        aria-label={`${stats.visits} visites`}
      >
        <Eye className="size-3.5 text-[#1E88E5]" aria-hidden="true" />
        <span className="tabular-nums">{numberFormat.format(stats.visits)}</span>
        <span className="text-muted-foreground">{stats.visits > 1 ? 'visites' : 'visite'}</span>
      </span>
      <span
        className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/80 px-3 py-1 text-foreground shadow-sm backdrop-blur"
        aria-label={`${stats.occupiedRooms} salles occupées`}
      >
        <DoorClosed className="size-3.5 text-[#D32F2F]" aria-hidden="true" />
        <span className="tabular-nums">{numberFormat.format(stats.occupiedRooms)}</span>
        <span className="text-muted-foreground">
          {stats.occupiedRooms > 1 ? 'salles occupées' : 'salle occupée'}
        </span>
      </span>
    </div>
  )
}
