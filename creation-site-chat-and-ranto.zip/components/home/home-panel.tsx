'use client'

import { useState, useTransition, useActionState } from 'react'
import { Check, Copy, KeyRound, LogIn, Loader2, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { createRoom, joinRoom, type JoinState } from '@/app/actions/rooms'

function formatInput(value: string) {
  const digits = value.replace(/\D/g, '').slice(0, 9)
  return digits.replace(/(\d{3})(?=\d)/g, '$1-')
}

export function HomePanel() {
  const [generated, setGenerated] = useState<string | null>(null)
  const [genError, setGenError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [generating, startGenerating] = useTransition()
  const [code, setCode] = useState('')
  const [showJoin, setShowJoin] = useState(false)
  const [state, formAction, joining] = useActionState<JoinState, FormData>(joinRoom, {})

  const handleGenerate = () => {
    setGenError(null)
    setCopied(false)
    startGenerating(async () => {
      const res = await createRoom()
      if (res.code) setGenerated(res.code)
      else setGenError(res.error ?? 'Erreur inattendue')
    })
  }

  const handleCopy = async () => {
    if (!generated) return
    try {
      await navigator.clipboard.writeText(generated)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }

  const useGenerated = () => {
    if (!generated) return
    setCode(generated)
    setShowJoin(true)
  }

  return (
    <div className="flex flex-col gap-4">
      <section aria-labelledby="get-code" className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-3">
          <span className="flex size-9 items-center justify-center rounded-lg bg-secondary text-primary">
            <Sparkles className="size-4" aria-hidden="true" />
          </span>
          <h2 id="get-code" className="font-medium">
            1. Obtenir un code de la salle
          </h2>
        </div>

        {generated ? (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2 rounded-xl bg-secondary px-4 py-3">
              <output aria-live="polite" className="font-mono text-2xl font-semibold tracking-wider text-primary">
                {generated}
              </output>
              <Button variant="ghost" size="icon" onClick={handleCopy} aria-label="Copier le code">
                {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              </Button>
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">
              Partagez ce code avec la personne de votre choix. Gardez-le précieusement : il ne sera plus affiché.
            </p>
            <Button onClick={useGenerated} className="h-11">
              <LogIn className="size-4" aria-hidden="true" />
              Entrer avec ce code
            </Button>
          </div>
        ) : (
          <Button onClick={handleGenerate} disabled={generating} className="h-11">
            {generating ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}
            Générer un code
          </Button>
        )}
        {genError && (
          <p role="alert" className="text-sm text-destructive">
            {genError}
          </p>
        )}
      </section>

      <section aria-labelledby="join" className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-3">
          <span className="flex size-9 items-center justify-center rounded-lg bg-secondary text-primary">
            <KeyRound className="size-4" aria-hidden="true" />
          </span>
          <h2 id="join" className="font-medium">
            2. Entrer dans la salle
          </h2>
        </div>

        {!showJoin && !state.error ? (
          <Button variant="secondary" className="h-11" onClick={() => setShowJoin(true)}>
            {"J'ai un code"}
          </Button>
        ) : (
          <form action={formAction} className="flex flex-col gap-3">
            <label className="flex flex-col gap-1.5">
              <span className="text-sm text-muted-foreground">Code de la salle</span>
              <input
                name="code"
                inputMode="numeric"
                autoComplete="off"
                placeholder="000-000-000"
                required
                value={code || state.code || ''}
                onChange={(e) => setCode(formatInput(e.target.value))}
                className="h-12 rounded-xl border border-input bg-background px-4 font-mono text-lg tracking-wider outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="text-sm text-muted-foreground">Votre nom</span>
              <input
                name="name"
                autoComplete="nickname"
                placeholder="Ex. Ranto"
                maxLength={40}
                required
                defaultValue={state.name}
                className="h-12 rounded-xl border border-input bg-background px-4 text-base outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {"De retour ? Entrez exactement le même nom que lors de votre première visite."}
            </p>
            {state.error && (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {state.error}
              </p>
            )}
            <Button type="submit" disabled={joining} className="h-11">
              {joining ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <LogIn className="size-4" />}
              Entrer
            </Button>
          </form>
        )}
      </section>
    </div>
  )
}
