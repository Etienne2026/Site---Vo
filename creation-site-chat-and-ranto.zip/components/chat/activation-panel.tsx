'use client'

import { useState, useTransition } from 'react'
import { KeyRound, Loader2, Lock, MessageCircle, Phone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { activateRoom } from '@/app/actions/rooms'

export type SupportInfo = { phoneDisplay: string; phoneHref: string; whatsappUrl: string; qrDataUrl: string }

export function ActivationPanel({
  code,
  displayCode,
  limit,
  support,
  onActivated,
}: {
  code: string
  displayCode: string
  limit: number
  support: SupportInfo
  onActivated: () => void
}) {
  const [value, setValue] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, startTransition] = useTransition()

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!value.trim()) return
    setError(null)
    startTransition(async () => {
      const res = await activateRoom(code, value)
      if (res.ok) {
        setValue('')
        onActivated()
      } else {
        setError(res.error ?? 'Activation impossible.')
      }
    })
  }

  return (
    <div className="flex flex-1 items-start justify-center overflow-y-auto bg-background/80 px-4 py-6 backdrop-blur-sm">
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="activation-title"
        aria-describedby="activation-desc"
        className="flex w-full max-w-sm flex-col gap-5 rounded-2xl border border-border bg-card p-5 shadow-xl"
      >
        <div className="flex flex-col items-center gap-3 text-center">
          <span className="flex size-12 items-center justify-center rounded-full bg-primary/15 text-primary">
            <Lock className="size-5" aria-hidden="true" />
          </span>
          <h2 id="activation-title" className="text-lg font-semibold text-balance">
            Salle en attente d&apos;activation
          </h2>
          <p className="text-xs text-muted-foreground">
            {`La salle `}
            <span className="font-mono font-medium text-foreground">{displayCode}</span>
            {` a atteint ses ${limit} utilisations. La conversation et l'historique sont masqués jusqu'à l'activation.`}
          </p>
        </div>

        <p id="activation-desc" className="rounded-xl bg-secondary px-4 py-3 text-sm leading-relaxed text-pretty">
          {'Pour continuer la conversation il faut acheter un code d’activation au '}
          <a href={support.phoneHref} className="font-semibold whitespace-nowrap text-primary underline-offset-4 hover:underline">
            {support.phoneDisplay}
          </a>
          {' ou scanner le code QR suivant sur WhatsApp.'}
        </p>

        <div className="flex flex-col items-center gap-3">
          <a
            href={support.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Ouvrir WhatsApp pour acheter un code d'activation"
            className="overflow-hidden rounded-xl shadow-sm"
          >
            {/* eslint-disable-next-line @next/next/no-img-element -- static QR image, no optimization needed */}
            <img
              src="/images/whatsapp-qr.jpg"
              alt="Code QR WhatsApp pour acheter un code d'activation"
              width={468}
              height={386}
              className="h-auto w-56"
            />
          </a>
          <div className="flex w-full gap-2">
            <a
              href={support.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-10 flex-1 items-center justify-center gap-2 rounded-lg bg-[#25D366] text-sm font-medium text-white hover:bg-[#1fb956]"
            >
              <MessageCircle className="size-4" aria-hidden="true" />
              WhatsApp
            </a>
            <a
              href={support.phoneHref}
              className="flex h-10 flex-1 items-center justify-center gap-2 rounded-lg border border-border text-sm font-medium hover:bg-secondary"
            >
              <Phone className="size-4" aria-hidden="true" />
              Appeler
            </a>
          </div>
        </div>

        <form onSubmit={submit} className="flex flex-col gap-3">
          <label className="flex flex-col gap-1.5">
            <span className="text-sm text-muted-foreground">Code d&apos;activation</span>
            <input
              name="activation"
              inputMode="numeric"
              autoComplete="one-time-code"
              placeholder="Entrez le code"
              maxLength={12}
              required
              value={value}
              onChange={(e) => setValue(e.target.value.replace(/\D/g, ''))}
              className="h-12 rounded-xl border border-input bg-background px-4 text-center font-mono text-lg tracking-widest outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
          {error && (
            <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          )}
          <Button type="submit" disabled={pending || !value} className="h-11">
            {pending ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <KeyRound className="size-4" aria-hidden="true" />}
            Activer la salle
          </Button>
        </form>
      </section>
    </div>
  )
}
