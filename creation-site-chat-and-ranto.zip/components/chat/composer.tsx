'use client'

import { useRef, useState } from 'react'
import { Image as ImageIcon, Loader2, Paperclip, SendHorizontal, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

const MAX_SIZE = 4 * 1024 * 1024
const MAX_DIMENSION = 1920

async function compressImage(file: File): Promise<File> {
  if (!file.type.startsWith('image/') || file.type === 'image/gif' || file.type === 'image/svg+xml') return file
  try {
    const bitmap = await createImageBitmap(file)
    const scale = Math.min(1, MAX_DIMENSION / Math.max(bitmap.width, bitmap.height))
    const canvas = document.createElement('canvas')
    canvas.width = Math.round(bitmap.width * scale)
    canvas.height = Math.round(bitmap.height * scale)
    canvas.getContext('2d')?.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
    bitmap.close()
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.85))
    if (!blob || blob.size >= file.size) return file
    const name = file.name.replace(/\.[^.]+$/, '') + '.jpg'
    return new File([blob], name, { type: 'image/jpeg' })
  } catch {
    return file
  }
}

export function Composer({ code, onSent }: { code: string; onSent: () => void }) {
  const [text, setText] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const imageInput = useRef<HTMLInputElement>(null)
  const fileInput = useRef<HTMLInputElement>(null)

  const pickFile = async (picked: File | undefined) => {
    setError(null)
    if (!picked) return
    const f = await compressImage(picked)
    if (f.size > MAX_SIZE) {
      setError('Fichier trop volumineux (4 Mo maximum).')
      return
    }
    setFile(f)
  }

  const send = async () => {
    const body = text.trim()
    if (sending || (!body && !file)) return
    setSending(true)
    setError(null)
    try {
      let res: Response
      if (file) {
        const fd = new FormData()
        fd.append('file', file)
        fd.append('body', body)
        res = await fetch(`/api/rooms/${code}/upload`, { method: 'POST', body: fd })
      } else {
        res = await fetch(`/api/rooms/${code}/messages`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ body }),
        })
      }
      if (!res.ok) {
        if (res.status === 423) onSent()
        const data = (await res.json().catch(() => ({}))) as { error?: string }
        throw new Error(data.error ?? "Échec de l'envoi")
      }
      setText('')
      setFile(null)
      onSent()
    } catch (e) {
      setError(e instanceof Error ? e.message : "Échec de l'envoi")
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="border-t border-border bg-card px-3 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      {file && (
        <div className="mb-2 flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-sm">
          <Paperclip className="size-4 shrink-0 text-primary" aria-hidden="true" />
          <span className="min-w-0 flex-1 truncate">{file.name}</span>
          <button type="button" onClick={() => setFile(null)} aria-label="Retirer le fichier" className="text-muted-foreground">
            <X className="size-4" />
          </button>
        </div>
      )}
      {error && (
        <p role="alert" className="mb-2 text-sm text-destructive">
          {error}
        </p>
      )}
      <form
        className="flex items-end gap-1.5"
        onSubmit={(e) => {
          e.preventDefault()
          send()
        }}
      >
        <input
          ref={imageInput}
          type="file"
          accept="image/*"
          className="sr-only"
          tabIndex={-1}
          onChange={(e) => {
            pickFile(e.target.files?.[0])
            e.target.value = ''
          }}
        />
        <input
          ref={fileInput}
          type="file"
          className="sr-only"
          tabIndex={-1}
          onChange={(e) => {
            pickFile(e.target.files?.[0])
            e.target.value = ''
          }}
        />
        <Button type="button" variant="ghost" size="icon" aria-label="Envoyer une photo" onClick={() => imageInput.current?.click()}>
          <ImageIcon className="size-5" />
        </Button>
        <Button type="button" variant="ghost" size="icon" aria-label="Joindre un fichier" onClick={() => fileInput.current?.click()}>
          <Paperclip className="size-5" />
        </Button>
        <label className="sr-only" htmlFor="message">
          Message
        </label>
        <textarea
          id="message"
          rows={1}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              if (e.nativeEvent.isComposing || e.keyCode === 229) return
              e.preventDefault()
              send()
            }
          }}
          placeholder="Message…"
          className="max-h-32 min-h-10 flex-1 resize-none rounded-2xl border border-input bg-background px-3.5 py-2 text-base outline-none field-sizing-content focus-visible:ring-2 focus-visible:ring-ring"
        />
        <Button type="submit" size="icon" disabled={sending || (!text.trim() && !file)} aria-label="Envoyer" className="rounded-full">
          {sending ? <Loader2 className="size-4 animate-spin" /> : <SendHorizontal className="size-4" />}
        </Button>
      </form>
    </div>
  )
}
