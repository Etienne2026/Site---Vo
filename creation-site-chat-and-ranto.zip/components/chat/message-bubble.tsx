'use client'

import { useState } from 'react'
import { Download, FileText, Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils'

export type ChatMessage = {
  id: number
  sender: string
  mine: boolean
  body: string | null
  file: { name: string | null; type: string | null; size: number | null; url: string } | null
  createdAt: string
}

function formatSize(bytes: number | null) {
  if (!bytes) return ''
  if (bytes < 1024) return `${bytes} o`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`
  return `${(bytes / 1024 / 1024).toFixed(1)} Mo`
}

const timeFormat = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' })

export function MessageBubble({
  message,
  showSender,
  onDelete,
}: {
  message: ChatMessage
  showSender: boolean
  onDelete?: (id: number) => void
}) {
  const { mine, file } = message
  const [confirming, setConfirming] = useState(false)
  const isImage = file?.type?.startsWith('image/')

  return (
    <li className={cn('flex flex-col gap-1', mine ? 'items-end' : 'items-start', showSender && 'mt-2')}>
      {showSender && !mine && <span className="px-1 text-xs text-muted-foreground">{message.sender}</span>}
      <div
        className={cn(
          'flex max-w-[82%] flex-col gap-2 overflow-hidden rounded-2xl text-[15px] leading-relaxed',
          mine ? 'rounded-br-md bg-primary text-primary-foreground' : 'rounded-bl-md bg-secondary text-secondary-foreground',
          isImage ? 'p-1' : 'px-3.5 py-2',
        )}
      >
        {file && isImage && (
          <a href={file.url} target="_blank" rel="noreferrer">
            <img
              src={file.url || '/placeholder.svg'}
              alt={file.name ?? 'Image envoyée'}
              loading="lazy"
              className="max-h-80 w-full rounded-xl object-cover"
            />
          </a>
        )}
        {file && !isImage && (
          <a
            href={`${file.url}?download`}
            className={cn(
              'flex items-center gap-3 rounded-xl p-2',
              mine ? 'bg-primary-foreground/10' : 'bg-background/40',
            )}
          >
            <FileText className="size-8 shrink-0" aria-hidden="true" />
            <span className="flex min-w-0 flex-1 flex-col">
              <span className="truncate font-medium">{file.name}</span>
              <span className="text-xs opacity-75">{formatSize(file.size)}</span>
            </span>
            <Download className="size-4 shrink-0" aria-label="Télécharger" />
          </a>
        )}
        {message.body && (
          <p className={cn('whitespace-pre-wrap break-words', isImage && 'px-2.5 pb-1.5')}>{message.body}</p>
        )}
      </div>
      <div className="flex items-center gap-1 px-1">
        <time className="text-[11px] text-muted-foreground" dateTime={message.createdAt}>
          {timeFormat.format(new Date(message.createdAt))}
        </time>
        {mine && onDelete && (
          confirming ? (
            <span className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onDelete(message.id)}
                className="rounded-md bg-destructive/15 px-2 py-1 text-xs font-medium text-destructive"
              >
                Supprimer
              </button>
              <button
                type="button"
                onClick={() => setConfirming(false)}
                className="rounded-md px-2 py-1 text-xs text-muted-foreground"
              >
                Annuler
              </button>
            </span>
          ) : (
            <button
              type="button"
              onClick={() => setConfirming(true)}
              aria-label={file ? 'Supprimer ce fichier' : 'Supprimer ce message'}
              className="rounded-md p-1.5 text-muted-foreground transition-colors hover:text-destructive"
            >
              <Trash2 className="size-3.5" aria-hidden="true" />
            </button>
          )
        )}
      </div>
    </li>
  )
}
