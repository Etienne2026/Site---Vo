'use client'

import Link from 'next/link'
import { useEffect, useRef } from 'react'
import useSWR from 'swr'
import { Home, Loader2, Lock, LogOut, ShieldCheck, Users } from 'lucide-react'
import { Button, buttonVariants } from '@/components/ui/button'
import { logout } from '@/app/actions/rooms'
import { cn } from '@/lib/utils'
import { MessageBubble, type ChatMessage } from './message-bubble'
import { Composer } from './composer'
import { ActivationPanel, type SupportInfo } from './activation-panel'

type RoomData = {
  me: string
  members: string[]
  locked: boolean
  uses: number
  limit: number
  messages: ChatMessage[]
}

type Usage = { uses: number; limit: number; locked: boolean }

const fetcher = async (url: string) => {
  const res = await fetch(url, { cache: 'no-store' })
  if (res.status === 401 || res.status === 403) {
    window.location.href = '/'
    throw new Error('Accès refusé')
  }
  if (!res.ok) throw new Error('Erreur réseau')
  return res.json() as Promise<RoomData>
}

export function ChatRoom({
  code,
  displayCode,
  me,
  isAdmin,
  initialUsage,
  support,
}: {
  code: string
  displayCode: string
  me: string
  isAdmin: boolean
  initialUsage: Usage
  support: SupportInfo
}) {
  const key = `/api/rooms/${code}/messages`
  const { data, error, mutate, isLoading } = useSWR(key, fetcher, { refreshInterval: 2500 })
  const endRef = useRef<HTMLDivElement>(null)
  const lastId = data?.messages.at(-1)?.id

  const locked = data ? data.locked : initialUsage.locked
  const uses = data?.uses ?? initialUsage.uses
  const limit = data?.limit ?? initialUsage.limit

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' })
  }, [lastId])

  const other = data?.members.find((m) => m !== me)

  async function deleteMessage(id: number) {
    await mutate(
      async (current) => {
        const res = await fetch(`/api/rooms/${code}/messages/${id}`, { method: 'DELETE' })
        if (!res.ok) throw new Error('Suppression impossible')
        return current && { ...current, messages: current.messages.filter((m) => m.id !== id) }
      },
      {
        optimisticData: (current) =>
          current ? { ...current, messages: current.messages.filter((m) => m.id !== id) } : current!,
        rollbackOnError: true,
        revalidate: true,
      },
    ).catch(() => alert('Impossible de supprimer ce message.'))
  }

  return (
    <div className="mx-auto flex h-dvh w-full max-w-2xl flex-col">
      <header className="flex items-center gap-2 border-b border-border bg-card px-3 py-2.5">
        <Link href="/" aria-label="Retour à l'accueil" className={buttonVariants({ variant: 'ghost', size: 'icon-lg' })}>
          <Home className="size-5" />
        </Link>
        <div className="flex min-w-0 flex-1 flex-col">
          <span className="flex items-center gap-1.5 truncate text-sm font-medium">
            {isAdmin ? (
              <>
                <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
                {"Salle d'administration"}
              </>
            ) : other ? (
              other
            ) : (
              "En attente de l'autre personne…"
            )}
          </span>
          <span className="flex items-center gap-1 font-mono text-xs text-muted-foreground">
            <Users className="size-3" aria-hidden="true" />
            {displayCode}
            {!isAdmin && <span className="font-sans">{`· ${data?.members.length ?? 1}/2`}</span>}
          </span>
        </div>
        {!isAdmin && (
          <span
            title="Nombre d'utilisations de la salle"
            className={cn(
              'flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium tabular-nums',
              locked ? 'bg-destructive/15 text-destructive' : uses >= limit - 2 ? 'bg-primary/15 text-primary' : 'bg-secondary text-muted-foreground',
            )}
          >
            {locked && <Lock className="size-3" aria-hidden="true" />}
            <span className="sr-only">Utilisations :</span>
            {`${uses}/${limit}`}
          </span>
        )}
        <form action={logout}>
          <Button type="submit" variant="ghost" size="sm" className="text-muted-foreground" aria-label="Déconnexion">
            <LogOut className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">Déconnexion</span>
          </Button>
        </form>
      </header>

      {locked ? (
        <ActivationPanel
          code={code}
          displayCode={displayCode}
          limit={limit}
          support={support}
          onActivated={() => mutate()}
        />
      ) : (
        <>
          <div className="flex-1 overflow-y-auto px-3 py-4" aria-live="polite">
            {isLoading ? (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                <Loader2 className="size-5 animate-spin" aria-label="Chargement" />
              </div>
            ) : data && data.messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center gap-2 px-6 text-center">
                <p className="font-medium">{`Bienvenue, ${me}`}</p>
                <p className="text-sm leading-relaxed text-muted-foreground text-pretty">
                  {isAdmin
                    ? "Les demandes d'activation des salles apparaîtront ici."
                    : other
                      ? `Vous êtes avec ${other}. Écrivez le premier message.`
                      : `Partagez le code ${displayCode} avec votre correspondant pour commencer.`}
                </p>
              </div>
            ) : (
              <ul className="flex flex-col gap-2">
                {data?.messages.map((m, i) => (
                  <MessageBubble
                    key={m.id}
                    message={m}
                    showSender={data.messages[i - 1]?.sender !== m.sender}
                    onDelete={deleteMessage}
                  />
                ))}
              </ul>
            )}
            {error && !data && <p className="text-center text-sm text-destructive">Connexion perdue, nouvelle tentative…</p>}
            <div ref={endRef} />
          </div>

          <Composer code={code} onSent={() => mutate()} />
        </>
      )}
    </div>
  )
}
