CREATE TABLE IF NOT EXISTS room_devices (
  id serial PRIMARY KEY,
  room_code text NOT NULL,
  device_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_code, device_id)
);

CREATE TABLE IF NOT EXISTS site_stats (
  key text PRIMARY KEY,
  value bigint NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS rooms (
  code text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  uses integer NOT NULL DEFAULT 0,
  locked boolean NOT NULL DEFAULT false,
  locked_at timestamptz,
  activations integer NOT NULL DEFAULT 0,
  failed_attempts integer NOT NULL DEFAULT 0,
  last_failed_at timestamptz
);

CREATE TABLE IF NOT EXISTS room_members (
  id serial PRIMARY KEY,
  room_code text NOT NULL,
  name text NOT NULL,
  name_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_code, name_key)
);

CREATE TABLE IF NOT EXISTS messages (
  id serial PRIMARY KEY,
  room_code text NOT NULL,
  sender text NOT NULL,
  body text,
  file_pathname text,
  file_name text,
  file_type text,
  file_size integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS messages_room_code_id_idx ON messages (room_code, id);
CREATE INDEX IF NOT EXISTS room_members_room_code_idx ON room_members (room_code);
