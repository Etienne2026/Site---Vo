import Image from 'next/image'
import Link from 'next/link'
import { KeyRound, Lock } from 'lucide-react'
import { getCurrentDeviceLock } from '@/lib/rental'
import { HomePanel } from '@/components/home/home-panel'
import { VisitCount } from '@/components/home/site-stats'
import { formatCode, getMember } from '@/lib/session'
import { getSiteStats } from '@/lib/stats'

export default async function HomePage() {
  const [member, stats, lockedCode] = await Promise.all([getMember(), getSiteStats(), getCurrentDeviceLock()])
  const canResumeLocked = lockedCode && member?.roomCode === lockedCode

  return (
    <div className="relative isolate min-h-dvh">
    <div className="fixed inset-0 -z-10" aria-hidden="true">
      <Image src="/images/home-bg.jpg" alt="" fill priority sizes="100vw" className="object-cover object-top" />
      <div className="absolute inset-0 bg-background/70" />
    </div>
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col gap-8 px-5 py-10">
      <header className="flex flex-col items-center gap-3 text-center">
        <Image
          src="/images/logo.jpg"
          alt="Logo AndRanto"
          width={64}
          height={64}
          priority
          className="size-16 rounded-2xl bg-white object-contain p-1 shadow-md"
        />
        <h1 className="text-3xl font-bold tracking-tight text-balance drop-shadow-sm">
          <span className="text-[#1E88E5]">And</span>
          <span className="text-[#D32F2F]">Ranto</span>
        </h1>
        <VisitCount initial={stats} />
        <p className="text-sm leading-relaxed text-foreground/90 text-pretty">
          Une salle privée pour deux personnes. Sans inscription, juste un code et votre nom.
        </p>
      </header>

      {lockedCode && (
        <div
          role="alert"
          className="flex flex-col gap-3 rounded-xl border border-destructive/40 bg-card px-4 py-3 text-sm"
        >
          <p className="flex items-start gap-2 leading-relaxed">
            <KeyRound className="mt-0.5 size-4 shrink-0 text-destructive" aria-hidden="true" />
            <span>
              {'Cet appareil est lié à la salle '}
              <span className="font-mono font-medium">{formatCode(lockedCode)}</span>
              {" qui attend son activation. Vous ne pouvez pas utiliser d'autre salle."}
            </span>
          </p>
          {canResumeLocked && (
            <Link
              href={`/salle/${lockedCode}`}
              className="flex h-10 items-center justify-center rounded-lg bg-primary text-sm font-medium text-primary-foreground"
            >
              Activer ma salle
            </Link>
          )}
        </div>
      )}

      {member && !lockedCode && (
        <Link
          href={`/salle/${member.roomCode}`}
          className="flex items-center justify-between gap-3 rounded-xl border border-primary/30 bg-accent px-4 py-3 text-sm text-accent-foreground"
        >
          <span>
            Reprendre la salle <span className="font-mono font-medium">{formatCode(member.roomCode)}</span> en tant que{' '}
            <span className="font-medium">{member.name}</span>
          </span>
          <span aria-hidden="true">{'→'}</span>
        </Link>
      )}

      <HomePanel />

      <footer className="mt-auto flex items-center justify-center gap-2 text-xs text-foreground/80">
        <Lock className="size-3.5" aria-hidden="true" />
        <span>Chaque salle est limitée à deux personnes.</span>
      </footer>
    </main>
    </div>
  )
}
