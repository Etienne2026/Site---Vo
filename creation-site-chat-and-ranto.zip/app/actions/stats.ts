'use server'

import { getOccupiedRoomCount, incrementVisitCount, type SiteStats } from '@/lib/stats'

export async function recordVisit(): Promise<SiteStats> {
  const [visits, occupiedRooms] = await Promise.all([incrementVisitCount(), getOccupiedRoomCount()])
  return { visits, occupiedRooms }
}
