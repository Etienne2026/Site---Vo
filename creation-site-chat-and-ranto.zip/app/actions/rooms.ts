'use server'

import { randomInt } from 'node:crypto'
import { redirect } from 'next/navigation'
import { and, count, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { roomMembers, rooms } from '@/lib/db/schema'
import {
  ADMIN_CODE,
  ADMIN_NAME,
  ensureAdminRoom,
  getCurrentDeviceLock,
  isAdminRoom,
  tryActivate,
  type ActivationResult,
} from '@/lib/rental'
import { clearSession, formatCode, getMember, nameKeyOf, normalizeCode, normalizeName, setSession } from '@/lib/session'

const ROOM_NOT_FOUND = "Cette salle n'existe pas. Vérifiez le code ou obtenez-en un nouveau."

function deviceLockedMessage(lockedCode: string) {
  return `Cet appareil est lié à la salle ${formatCode(lockedCode)} qui attend son activation. Vous pouvez seulement entrer dans cette salle pour l'activer.`
}

export async function createRoom(): Promise<{ code?: string; error?: string }> {
  const lockedCode = await getCurrentDeviceLock()
  if (lockedCode) return { error: deviceLockedMessage(lockedCode) }

  for (let attempt = 0; attempt < 5; attempt++) {
    const code = randomInt(1, 1_000_000_000).toString().padStart(9, '0')
    if (code === ADMIN_CODE) continue
    const inserted = await db.insert(rooms).values({ code }).onConflictDoNothing().returning({ code: rooms.code })
    if (inserted.length > 0) return { code: formatCode(code) }
  }
  return { error: 'Impossible de générer un code. Veuillez réessayer.' }
}

export type JoinState = { error?: string; code?: string; name?: string }

export async function joinRoom(_prev: JoinState, formData: FormData): Promise<JoinState> {
  const rawCode = String(formData.get('code') ?? '')
  const rawName = String(formData.get('name') ?? '')
  const code = normalizeCode(rawCode)
  const name = normalizeName(rawName).slice(0, 40)
  const keep = { code: rawCode, name: rawName }

  if (!code) return { ...keep, error: 'Le code doit contenir 9 chiffres (ex. 123-456-789).' }
  if (name.length < 2) return { ...keep, error: 'Veuillez entrer votre nom (2 caractères minimum).' }

  const nameKey = nameKeyOf(name)
  if (isAdminRoom(code)) {
    // Stay confidential: other users get the same answer as for a nonexistent room.
    if (nameKey !== nameKeyOf(ADMIN_NAME)) return { ...keep, error: ROOM_NOT_FOUND }
    await ensureAdminRoom()
  }

  // Admin2487 can always enter the admin room, even from a device tied to an expired room.
  if (!isAdminRoom(code)) {
    const lockedCode = await getCurrentDeviceLock(code)
    if (lockedCode) return { ...keep, error: deviceLockedMessage(lockedCode) }
  }

  const [room] = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1)
  if (!room) return { ...keep, error: ROOM_NOT_FOUND }

  const [existing] = await db
    .select({ id: roomMembers.id })
    .from(roomMembers)
    .where(and(eq(roomMembers.roomCode, code), eq(roomMembers.nameKey, nameKey)))
    .limit(1)

  if (!existing) {
    const [{ total }] = await db.select({ total: count() }).from(roomMembers).where(eq(roomMembers.roomCode, code))
    if (total >= 2) {
      return {
        ...keep,
        error:
          'Cette salle est déjà occupée par deux personnes, veuillez demander une autre salle. Si vous êtes membre de cette salle, entrez exactement le même nom.',
      }
    }
    await db.insert(roomMembers).values({ roomCode: code, name, nameKey }).onConflictDoNothing()
    const [{ total: after }] = await db
      .select({ total: count() })
      .from(roomMembers)
      .where(eq(roomMembers.roomCode, code))
    if (after > 2) {
      await db.delete(roomMembers).where(and(eq(roomMembers.roomCode, code), eq(roomMembers.nameKey, nameKey)))
      return { ...keep, error: 'Cette salle est déjà occupée par deux personnes, veuillez demander une autre salle.' }
    }
  }

  await setSession(code, nameKey)
  redirect(`/salle/${code}`)
}

export async function activateRoom(code: string, activationCode: string): Promise<ActivationResult> {
  const member = await getMember(code)
  if (!member) return { error: 'Accès refusé.' }
  return tryActivate(code, String(activationCode).slice(0, 12))
}

export async function logout() {
  await clearSession()
  redirect('/')
}
