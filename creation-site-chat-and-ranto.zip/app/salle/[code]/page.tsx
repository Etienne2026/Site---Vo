import { redirect } from 'next/navigation'
import type { Metadata } from 'next'
import QRCode from 'qrcode'
import { ChatRoom } from '@/components/chat/chat-room'
import { formatCode, getMember } from '@/lib/session'
import {
  SUPPORT_PHONE_DISPLAY,
  SUPPORT_PHONE_E164,
  getDeviceId,
  getLockedRoomForDevice,
  isAdminRoom,
  recordDevice,
  registerRoomUse,
  whatsappUrl,
} from '@/lib/rental'

export const metadata: Metadata = { title: 'Salle privée — AndRanto' }

export default async function RoomPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params
  const member = await getMember(code)
  if (!member) redirect('/')

  const deviceId = await getDeviceId()
  const isAdmin = isAdminRoom(code)
  if (!isAdmin && (await getLockedRoomForDevice(deviceId, code))) redirect('/')
  if (deviceId && !isAdmin) await recordDevice(code, deviceId)

  const usage = await registerRoomUse(code)
  const displayCode = formatCode(code)
  const waUrl = whatsappUrl(displayCode)
  const qrSvg = await QRCode.toString(waUrl, { type: 'svg', margin: 1, width: 192, errorCorrectionLevel: 'M' })

  return (
    <ChatRoom
      code={code}
      displayCode={displayCode}
      me={member.name}
      isAdmin={isAdmin}
      initialUsage={usage}
      support={{
        phoneDisplay: SUPPORT_PHONE_DISPLAY,
        phoneHref: `tel:+${SUPPORT_PHONE_E164}`,
        whatsappUrl: waUrl,
        qrDataUrl: `data:image/svg+xml;base64,${Buffer.from(qrSvg).toString('base64')}`,
      }}
    />
  )
}
