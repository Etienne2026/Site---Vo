import { NextResponse, type NextRequest } from 'next/server'
import { get } from '@vercel/blob'
import { and, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { messages } from '@/lib/db/schema'
import { getRoomAccess } from '@/lib/rental'
import { accessError } from '@/lib/room-access-response'

export async function GET(req: NextRequest, { params }: { params: Promise<{ code: string; id: string }> }) {
  const { code, id } = await params
  const access = await getRoomAccess(code)
  if (access.status !== 'ok') return accessError(access.status)

  const messageId = Number(id)
  if (!Number.isInteger(messageId)) return new NextResponse('Not found', { status: 404 })

  const [msg] = await db
    .select()
    .from(messages)
    .where(and(eq(messages.id, messageId), eq(messages.roomCode, code)))
    .limit(1)
  if (!msg?.filePathname) return new NextResponse('Not found', { status: 404 })

  let result: Awaited<ReturnType<typeof get>>
  try {
    result = await get(msg.filePathname, {
      access: 'private',
      ifNoneMatch: req.headers.get('if-none-match') ?? undefined,
    })
  } catch (error) {
    console.error('File fetch error:', error)
    return new NextResponse('Not found', { status: 404 })
  }
  if (!result) return new NextResponse('Not found', { status: 404 })

  if (result.statusCode === 304) {
    return new NextResponse(null, {
      status: 304,
      headers: { ETag: result.blob.etag, 'Cache-Control': 'private, no-cache' },
    })
  }

  const download = req.nextUrl.searchParams.has('download')
  const filename = encodeURIComponent(msg.fileName ?? 'fichier')
  return new NextResponse(result.stream, {
    headers: {
      'Content-Type': result.blob.contentType,
      ETag: result.blob.etag,
      'Cache-Control': 'private, no-cache',
      'Content-Disposition': `${download ? 'attachment' : 'inline'}; filename*=UTF-8''${filename}`,
      'X-Content-Type-Options': 'nosniff',
    },
  })
}
