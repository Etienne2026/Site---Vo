import { NextResponse, type NextRequest } from 'next/server'
import { put } from '@vercel/blob'
import { db } from '@/lib/db'
import { messages } from '@/lib/db/schema'
import { getRoomAccess } from '@/lib/rental'
import { accessError } from '@/lib/room-access-response'

const MAX_SIZE = 4 * 1024 * 1024

export async function POST(req: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params
  const access = await getRoomAccess(code)
  if (access.status !== 'ok') return accessError(access.status)
  const { member } = access

  const formData = await req.formData()
  const file = formData.get('file')
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: 'Aucun fichier' }, { status: 400 })
  }
  if (file.size > MAX_SIZE) {
    return NextResponse.json({ error: 'Fichier trop volumineux (4 Mo maximum)' }, { status: 413 })
  }

  const caption = String(formData.get('body') ?? '').trim().slice(0, 4000) || null
  const safeName = file.name.replace(/[^\w.\-]+/g, '_').slice(-100) || 'fichier'

  try {
    const blob = await put(`rooms/${code}/${safeName}`, file, {
      access: 'private',
      addRandomSuffix: true,
      contentType: file.type || 'application/octet-stream',
    })
    await db.insert(messages).values({
      roomCode: code,
      sender: member.name,
      body: caption,
      filePathname: blob.pathname,
      fileName: file.name.slice(0, 200),
      fileType: file.type || 'application/octet-stream',
      fileSize: file.size,
    })
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json({ error: "Échec de l'envoi du fichier" }, { status: 500 })
  }
}
