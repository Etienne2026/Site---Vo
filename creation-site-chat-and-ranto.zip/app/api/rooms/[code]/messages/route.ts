import { NextResponse, type NextRequest } from 'next/server'
import { asc, desc, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { messages, roomMembers } from '@/lib/db/schema'
import { getRoomAccess, USE_LIMIT } from '@/lib/rental'
import { accessError } from '@/lib/room-access-response'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params
  const access = await getRoomAccess(code)
  if (access.status === 'unauthorized' || access.status === 'blocked') return accessError(access.status)
  const { member } = access

  const members = await db
    .select({ name: roomMembers.name })
    .from(roomMembers)
    .where(eq(roomMembers.roomCode, code))
    .orderBy(asc(roomMembers.id))

  const base = { me: member.name, members: members.map((m) => m.name) }
  const noStore = { headers: { 'Cache-Control': 'no-store' } }

  if (access.status === 'locked') {
    return NextResponse.json({ ...base, locked: true, uses: USE_LIMIT, limit: USE_LIMIT, messages: [] }, noStore)
  }

  const rows = await db.select().from(messages).where(eq(messages.roomCode, code)).orderBy(desc(messages.id)).limit(300)

  return NextResponse.json(
    {
      ...base,
      locked: false,
      uses: access.usage.uses,
      limit: access.usage.limit,
      messages: rows.reverse().map((m) => ({
        id: m.id,
        sender: m.sender,
        mine: m.sender === member.name,
        body: m.body,
        file: m.filePathname
          ? { name: m.fileName, type: m.fileType, size: m.fileSize, url: `/api/rooms/${code}/file/${m.id}` }
          : null,
        createdAt: m.createdAt,
      })),
    },
    noStore,
  )
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params
  const access = await getRoomAccess(code)
  if (access.status !== 'ok') return accessError(access.status)

  const { body } = (await req.json().catch(() => ({}))) as { body?: unknown }
  const text = typeof body === 'string' ? body.trim().slice(0, 4000) : ''
  if (!text) return NextResponse.json({ error: 'Message vide' }, { status: 400 })

  await db.insert(messages).values({ roomCode: code, sender: access.member.name, body: text })
  return NextResponse.json({ ok: true })
}
