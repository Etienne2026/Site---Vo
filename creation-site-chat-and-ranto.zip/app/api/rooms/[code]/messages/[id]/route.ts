import { NextResponse, type NextRequest } from 'next/server'
import { del } from '@vercel/blob'
import { and, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { messages } from '@/lib/db/schema'
import { getRoomAccess } from '@/lib/rental'
import { accessError } from '@/lib/room-access-response'

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ code: string; id: string }> }) {
  const { code, id } = await params
  const access = await getRoomAccess(code)
  if (access.status !== 'ok') return accessError(access.status)
  const { member } = access

  const messageId = Number(id)
  if (!Number.isInteger(messageId)) return NextResponse.json({ error: 'Introuvable' }, { status: 404 })

  const [deleted] = await db
    .delete(messages)
    .where(and(eq(messages.id, messageId), eq(messages.roomCode, code), eq(messages.sender, member.name)))
    .returning({ filePathname: messages.filePathname })

  if (!deleted) return NextResponse.json({ error: 'Introuvable' }, { status: 404 })

  if (deleted.filePathname) {
    await del(deleted.filePathname).catch((err) => console.error('Blob delete failed:', err))
  }

  return NextResponse.json({ ok: true })
}
