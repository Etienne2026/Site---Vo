import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist } from 'next/font/google'
import './globals.css'

const geist = Geist({ subsets: ['latin'], variable: '--font-sans' })

export const metadata: Metadata = {
  title: 'AndRanto — Chat privé à deux',
  description:
    'AndRanto : une salle de discussion privée pour deux personnes, sans inscription. Un code, deux noms, une conversation confidentielle.',
  generator: 'v0.app',
  applicationName: 'AndRanto',
  robots: { index: false, follow: false },
  icons: {
    icon: [{ url: '/images/logo.jpg', type: 'image/jpeg' }],
    apple: '/images/logo.jpg',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#14171c',
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  interactiveWidget: 'resizes-content',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className={`dark ${geist.variable}`}>
      <body className="font-sans antialiased bg-background text-foreground">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
