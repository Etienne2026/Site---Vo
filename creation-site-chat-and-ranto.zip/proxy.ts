import { NextResponse, type NextRequest } from 'next/server'
import { DEVICE_COOKIE, DEVICE_MAX_AGE } from '@/lib/device-cookie'

export function proxy(req: NextRequest) {
  if (req.cookies.get(DEVICE_COOKIE)?.value) return NextResponse.next()

  const deviceId = crypto.randomUUID()
  // Also inject it into the incoming request so server code sees it on the very first visit.
  req.cookies.set(DEVICE_COOKIE, deviceId)
  const res = NextResponse.next({ request: { headers: req.headers } })
  res.cookies.set(DEVICE_COOKIE, deviceId, {
    httpOnly: true,
    secure: true,
    sameSite: process.env.NODE_ENV === 'development' ? 'none' : 'lax',
    path: '/',
    maxAge: DEVICE_MAX_AGE,
  })
  return res
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|images/|favicon|icon|apple-icon|manifest).*)'],
}
