import { NextResponse } from 'next/server'

export function accessError(status: 'unauthorized' | 'blocked' | 'locked') {
  if (status === 'unauthorized') return NextResponse.json({ error: 'Accès refusé' }, { status: 401 })
  if (status === 'blocked') {
    return NextResponse.json({ error: 'Cet appareil est lié à une autre salle en attente d’activation.' }, { status: 403 })
  }
  return NextResponse.json(
    { error: 'Salle en attente d’activation. Entrez le code d’activation pour continuer.' },
    { status: 423 },
  )
}
