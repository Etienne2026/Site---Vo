import { createHash, createHmac, timingSafeEqual } from 'node:crypto'
import { cookies } from 'next/headers'
import { and, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { roomMembers } from '@/lib/db/schema'

const COOKIE_NAME = 'andranto_session'
const MAX_AGE = 60 * 60 * 24 * 30

function getKey() {
  const secret = process.env.SESSION_SECRET ?? process.env.DATABASE_URL
  if (!secret) throw new Error('Missing session secret')
  return createHash('sha256').update(`andranto:${secret}`).digest()
}

function sign(payload: string) {
  return createHmac('sha256', getKey()).update(payload).digest('base64url')
}

export function normalizeCode(input: string) {
  const digits = input.replace(/\D/g, '')
  return digits.length === 9 ? digits : null
}

export function formatCode(code: string) {
  return `${code.slice(0, 3)}-${code.slice(3, 6)}-${code.slice(6, 9)}`
}

export function normalizeName(input: string) {
  return input.trim().replace(/\s+/g, ' ')
}

export function nameKeyOf(name: string) {
  return normalizeName(name).toLocaleLowerCase('fr')
}

export async function setSession(code: string, nameKey: string) {
  const payload = `${code}.${Buffer.from(nameKey).toString('base64url')}`
  const store = await cookies()
  const isDev = process.env.NODE_ENV === 'development'
  store.set(COOKIE_NAME, `${payload}.${sign(payload)}`, {
    httpOnly: true,
    secure: true,
    sameSite: isDev ? 'none' : 'lax',
    path: '/',
    maxAge: MAX_AGE,
  })
}

export async function clearSession() {
  const store = await cookies()
  store.delete(COOKIE_NAME)
}

async function readSession() {
  const store = await cookies()
  const raw = store.get(COOKIE_NAME)?.value
  if (!raw) return null
  const parts = raw.split('.')
  if (parts.length !== 3) return null
  const [code, encodedKey, signature] = parts
  const expected = Buffer.from(sign(`${code}.${encodedKey}`))
  const given = Buffer.from(signature)
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return null
  return { code, nameKey: Buffer.from(encodedKey, 'base64url').toString() }
}

export async function getMember(expectedCode?: string) {
  const session = await readSession()
  if (!session) return null
  if (expectedCode && session.code !== expectedCode) return null
  const [member] = await db
    .select()
    .from(roomMembers)
    .where(and(eq(roomMembers.roomCode, session.code), eq(roomMembers.nameKey, session.nameKey)))
    .limit(1)
  return member ?? null
}
