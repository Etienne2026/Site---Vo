export const DEVICE_COOKIE = 'andranto_device'
export const DEVICE_MAX_AGE = 60 * 60 * 24 * 365 * 5
