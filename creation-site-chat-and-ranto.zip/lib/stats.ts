import { countDistinct, eq, ne, sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { roomMembers, siteStats } from '@/lib/db/schema'

export type SiteStats = { visits: number; occupiedRooms: number }

export async function getVisitCount(): Promise<number> {
  const [row] = await db.select({ value: siteStats.value }).from(siteStats).where(eq(siteStats.key, 'visits')).limit(1)
  return row?.value ?? 0
}

export async function incrementVisitCount(): Promise<number> {
  const [row] = await db
    .insert(siteStats)
    .values({ key: 'visits', value: 1 })
    .onConflictDoUpdate({ target: siteStats.key, set: { value: sql`${siteStats.value} + 1` } })
    .returning({ value: siteStats.value })
  return row.value
}

export async function getOccupiedRoomCount(): Promise<number> {
  const [row] = await db
    .select({ total: countDistinct(roomMembers.roomCode) })
    .from(roomMembers)
    .where(ne(roomMembers.roomCode, '000000000'))
  return row?.total ?? 0
}

export async function getSiteStats(): Promise<SiteStats> {
  const [visits, occupiedRooms] = await Promise.all([getVisitCount(), getOccupiedRoomCount()])
  return { visits, occupiedRooms }
}
