import { cookies } from 'next/headers'
import { and, asc, eq, ne, sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { messages, roomDevices, roomMembers, rooms } from '@/lib/db/schema'
import { DEVICE_COOKIE } from '@/lib/device-cookie'
import { formatCode, getMember } from '@/lib/session'

export const ADMIN_CODE = '000000000'
export const ADMIN_NAME = 'Admin2487'
export const USE_LIMIT = 10
export const MAX_FAILED_ATTEMPTS = 5
export const FAILED_WINDOW_MINUTES = 15
export const SUPPORT_PHONE_DISPLAY = '+261 33 13 290 57'
export const SUPPORT_PHONE_E164 = '261331329057'

const SYSTEM_SENDER = 'Système'

export function isAdminRoom(code: string) {
  return code === ADMIN_CODE
}

export function whatsappUrl(displayCode: string) {
  const text = `Bonjour, je souhaite acheter un code d'activation pour la salle ${displayCode}.`
  return `https://wa.me/${SUPPORT_PHONE_E164}?text=${encodeURIComponent(text)}`
}

function charCount(name: string) {
  return Array.from(name).length
}

async function getMemberNames(code: string) {
  const rows = await db
    .select({ name: roomMembers.name })
    .from(roomMembers)
    .where(eq(roomMembers.roomCode, code))
    .orderBy(asc(roomMembers.id))
    .limit(2)
  return rows.map((r) => r.name)
}

/** Activation code = chars(first member) × chars(second member) × year the room was locked. */
function activationCodeFor(names: string[], lockedAt?: Date | null) {
  if (names.length < 2) return null
  const year = (lockedAt ?? new Date()).getFullYear()
  return charCount(names[0]) * charCount(names[1]) * year
}

export async function ensureAdminRoom() {
  await db.insert(rooms).values({ code: ADMIN_CODE }).onConflictDoNothing()
}

async function notifyAdmin(body: string) {
  await ensureAdminRoom()
  await db.insert(messages).values({ roomCode: ADMIN_CODE, sender: SYSTEM_SENDER, body })
}

export async function getDeviceId() {
  const store = await cookies()
  return store.get(DEVICE_COOKIE)?.value ?? null
}

export async function recordDevice(code: string, deviceId: string) {
  await db.insert(roomDevices).values({ roomCode: code, deviceId }).onConflictDoNothing()
}

/** Returns the code of a locked room this device belongs to (other than `exceptCode`), if any. */
export async function getLockedRoomForDevice(deviceId: string | null, exceptCode?: string) {
  if (!deviceId) return null
  const conditions = [eq(roomDevices.deviceId, deviceId), eq(rooms.locked, true), eq(rooms.activations, 0)]
  if (exceptCode) conditions.push(ne(rooms.code, exceptCode))
  const [row] = await db
    .select({ code: rooms.code })
    .from(roomDevices)
    .innerJoin(rooms, eq(rooms.code, roomDevices.roomCode))
    .where(and(...conditions))
    .limit(1)
  return row?.code ?? null
}

export async function getCurrentDeviceLock(exceptCode?: string) {
  return getLockedRoomForDevice(await getDeviceId(), exceptCode)
}

async function lockIfDue(code: string, uses: number) {
  if (isAdminRoom(code) || uses < USE_LIMIT) return false
  const names = await getMemberNames(code)
  const lockedAt = new Date()
  const activationCode = activationCodeFor(names, lockedAt)
  if (activationCode === null) return false

  const [locked] = await db
    .update(rooms)
    .set({ locked: true, lockedAt, failedAttempts: 0 })
    .where(and(eq(rooms.code, code), eq(rooms.locked, false), eq(rooms.activations, 0)))
    .returning({ code: rooms.code })
  if (!locked) return true

  await notifyAdmin(
    [
      "Demande d'activation",
      `Salle : ${formatCode(code)}`,
      `Membres : ${names[0]} et ${names[1]}`,
      `Code d'activation : ${activationCode}`,
    ].join('\n'),
  )
  return true
}

export type RoomUsage = { uses: number; limit: number; locked: boolean; activated: boolean }

const UNLIMITED: RoomUsage = { uses: 0, limit: USE_LIMIT, locked: false, activated: true }

/** Counts one use of the room (an entry by one of its members) and locks it once the limit is reached. */
export async function registerRoomUse(code: string): Promise<RoomUsage> {
  if (isAdminRoom(code)) return UNLIMITED

  // Rooms activated once with the real code are unlocked forever and no longer counted.
  const [updated] = await db
    .update(rooms)
    .set({ uses: sql`${rooms.uses} + 1` })
    .where(and(eq(rooms.code, code), eq(rooms.locked, false), eq(rooms.activations, 0)))
    .returning({ uses: rooms.uses })

  if (!updated) return getRoomUsage(code)
  const locked = await lockIfDue(code, updated.uses)
  return { uses: Math.min(updated.uses, USE_LIMIT), limit: USE_LIMIT, locked, activated: false }
}

export async function getRoomUsage(code: string): Promise<RoomUsage> {
  const [room] = await db
    .select({ uses: rooms.uses, locked: rooms.locked, activations: rooms.activations })
    .from(rooms)
    .where(eq(rooms.code, code))
    .limit(1)
  if (!room || isAdminRoom(code)) return UNLIMITED
  if (room.activations > 0) {
    if (room.locked) await db.update(rooms).set({ locked: false, lockedAt: null }).where(eq(rooms.code, code))
    return UNLIMITED
  }
  // A room may have reached the limit while it still had a single member.
  const locked = room.locked || (await lockIfDue(code, room.uses))
  return { uses: Math.min(room.uses, USE_LIMIT), limit: USE_LIMIT, locked, activated: false }
}

/** Resolves the session member for a room and whether they may currently chat in it. */
export async function getRoomAccess(code: string) {
  const member = await getMember(code)
  if (!member) return { status: 'unauthorized' as const }
  // The admin can always use the admin room, even from a device tied to a locked room.
  if (!isAdminRoom(code) && (await getCurrentDeviceLock(code))) return { status: 'blocked' as const, member }
  const usage = await getRoomUsage(code)
  if (usage.locked) return { status: 'locked' as const, member, usage }
  return { status: 'ok' as const, member, usage }
}

/** True when the current session belongs to the admin room member. */
export async function isAdminSession() {
  const member = await getMember(ADMIN_CODE)
  return member?.nameKey === ADMIN_NAME.toLocaleLowerCase('fr')
}

export async function getLockedRooms() {
  const locked = await db
    .select({ code: rooms.code, lockedAt: rooms.lockedAt, activations: rooms.activations })
    .from(rooms)
    .where(and(eq(rooms.locked, true), eq(rooms.activations, 0), ne(rooms.code, ADMIN_CODE)))
    .orderBy(sql`${rooms.lockedAt} desc nulls last`)

  return Promise.all(
    locked.map(async (room) => {
      const names = await getMemberNames(room.code)
      const [{ total }] = await db
        .select({ total: sql<number>`count(*)::int` })
        .from(messages)
        .where(eq(messages.roomCode, room.code))
      return { ...room, names, messageCount: total, activationCode: activationCodeFor(names, room.lockedAt) }
    }),
  )
}

export type ActivationResult = { ok?: true; error?: string }

export async function tryActivate(code: string, input: string): Promise<ActivationResult> {
  const [room] = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1)
  if (!room) return { error: 'Salle introuvable.' }
  if (!room.locked || room.activations > 0) return { ok: true }

  const windowStart = Date.now() - FAILED_WINDOW_MINUTES * 60_000
  const recentFailures = room.lastFailedAt && room.lastFailedAt.getTime() > windowStart ? room.failedAttempts : 0
  if (recentFailures >= MAX_FAILED_ATTEMPTS) {
    const waitMs = room.lastFailedAt!.getTime() + FAILED_WINDOW_MINUTES * 60_000 - Date.now()
    const minutes = Math.max(1, Math.ceil(waitMs / 60_000))
    return { error: `Trop de tentatives. Réessayez dans ${minutes} min.` }
  }

  const digits = input.replace(/\D/g, '')
  const expected = activationCodeFor(await getMemberNames(code), room.lockedAt)
  if (!digits || expected === null || Number(digits) !== expected) {
    await db
      .update(rooms)
      .set({ failedAttempts: recentFailures + 1, lastFailedAt: new Date() })
      .where(eq(rooms.code, code))
    const left = MAX_FAILED_ATTEMPTS - recentFailures - 1
    return {
      error:
        left > 0
          ? `Code d'activation incorrect. ${left} tentative${left > 1 ? 's' : ''} restante${left > 1 ? 's' : ''}.`
          : `Code d'activation incorrect. Réessayez dans ${FAILED_WINDOW_MINUTES} min.`,
    }
  }

  const [activated] = await db
    .update(rooms)
    .set({
      locked: false,
      lockedAt: null,
      uses: 0,
      activations: sql`${rooms.activations} + 1`,
      failedAttempts: 0,
      lastFailedAt: null,
    })
    .where(and(eq(rooms.code, code), eq(rooms.locked, true)))
    .returning({ code: rooms.code })

  if (activated) await notifyAdmin(`Salle ${formatCode(code)} activée définitivement.`)
  return { ok: true }
}
