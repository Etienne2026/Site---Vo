import { drizzle, type NodePgDatabase } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'
import * as schema from './schema'

type Database = NodePgDatabase<typeof schema>

// The pool is cached on globalThis to survive HMR; keying it by URL prevents
// reusing a pool created before DATABASE_URL was available or changed.
const globalForDb = globalThis as unknown as {
  pool?: Pool
  poolUrl?: string
  db?: Database
}

function getConnectionString() {
  const connectionString = process.env.DATABASE_URL
  if (!connectionString) throw new Error('DATABASE_URL is not set')
  return connectionString
}

export function getPool(): Pool {
  const connectionString = getConnectionString()
  if (globalForDb.pool && globalForDb.poolUrl === connectionString) return globalForDb.pool

  const isLocal = /@(localhost|127\.0\.0\.1)[:/]/.test(connectionString)
  const pool = new Pool({
    connectionString,
    ssl: isLocal ? false : { rejectUnauthorized: true },
  })
  globalForDb.pool = pool
  globalForDb.poolUrl = connectionString
  globalForDb.db = undefined
  return pool
}

function getDb(): Database {
  const pool = getPool()
  if (!globalForDb.db) globalForDb.db = drizzle(pool, { schema })
  return globalForDb.db
}

// Connecting lazily keeps `next build` from failing when DATABASE_URL is only
// available at runtime.
export const db = new Proxy({} as Database, {
  get(_target, prop) {
    const instance = getDb()
    const value = Reflect.get(instance, prop, instance)
    return typeof value === 'function' ? value.bind(instance) : value
  },
})
