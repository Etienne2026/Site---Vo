import { bigint, boolean, integer, pgTable, serial, text, timestamp, unique } from 'drizzle-orm/pg-core'

export const roomDevices = pgTable(
  'room_devices',
  {
    id: serial('id').primaryKey(),
    roomCode: text('room_code').notNull(),
    deviceId: text('device_id').notNull(),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.roomCode, t.deviceId)],
)

export const siteStats = pgTable('site_stats', {
  key: text('key').primaryKey(),
  value: bigint('value', { mode: 'number' }).notNull().default(0),
})

export const rooms = pgTable('rooms', {
  code: text('code').primaryKey(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  uses: integer('uses').notNull().default(0),
  locked: boolean('locked').notNull().default(false),
  lockedAt: timestamp('locked_at', { withTimezone: true }),
  activations: integer('activations').notNull().default(0),
  failedAttempts: integer('failed_attempts').notNull().default(0),
  lastFailedAt: timestamp('last_failed_at', { withTimezone: true }),
})

export const roomMembers = pgTable(
  'room_members',
  {
    id: serial('id').primaryKey(),
    roomCode: text('room_code').notNull(),
    name: text('name').notNull(),
    nameKey: text('name_key').notNull(),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.roomCode, t.nameKey)],
)

export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  roomCode: text('room_code').notNull(),
  sender: text('sender').notNull(),
  body: text('body'),
  filePathname: text('file_pathname'),
  fileName: text('file_name'),
  fileType: text('file_type'),
  fileSize: integer('file_size'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})
